export default {
    todos: [],
    dones: [],
    dusts: []
};