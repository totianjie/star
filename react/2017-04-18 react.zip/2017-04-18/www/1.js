var count = 0;
while(true){
	count++;
	console.log(count);
};